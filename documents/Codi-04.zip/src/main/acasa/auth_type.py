from enum import Enum


class AuthType(Enum):
    NO_AUTH = 0
    OAUTH = 1